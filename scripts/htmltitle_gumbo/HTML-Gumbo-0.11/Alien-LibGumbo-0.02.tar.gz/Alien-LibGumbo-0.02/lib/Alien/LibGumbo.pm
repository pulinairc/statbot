package Alien::LibGumbo;

use v5.10;
use strict;
use warnings;

our $VERSION = 0.02;

use parent 'Alien::Base';

# ABSTRACT: gumbo parser library

1;